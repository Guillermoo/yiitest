<p>Estimado usuario, usted ha solicitado registrarse en el sistema, pronto sera notificado sobre la activacion de su cuenta, por mientras tome nota de los datos:</p>
<p><?php echo "usuario: ".$model->username." email: ".$model->email;?></p>
<p><?php echo "su nueva clave es: ".$password;?></p>
<p>Por favor tome las precauciones necesarias para guardar su nueva clave</p>