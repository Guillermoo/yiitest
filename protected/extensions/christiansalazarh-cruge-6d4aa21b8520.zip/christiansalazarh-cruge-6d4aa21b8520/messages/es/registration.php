<?php
/**
 * Cruge Registration messages
 * @author Ricardo Obregón <ricardo@obregon.co>
 * @date 4/12/12 06:11 PM
 */
return array(
    'The account has been created!' => '¡La cuenta ha sido creada!',
    'Click here to login using new credentials:' => 'Haga click aquí para iniciar sesión con sus nuevas credenciales:',
);